package com.backfunctionimpl.travel.travelTransportation.enums;

public enum Type {
    TRANSPORTATION,CAR
}
