package com.backfunctionimpl.travel.travelPlace.dto;

import lombok.Data;

@Data
public class Photo {
    private String photo_reference;
    private int height;
    private int width;
}
