package com.backfunctionimpl.post.enums;

public enum Category {

    TIPS ,FREE, MATE

}
