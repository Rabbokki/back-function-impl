package com.backfunctionimpl.tag.enums;

public enum Country {
    오스트레일리아,
    브라질,
    캐나다,
    프랑스,
    독일,
    홍콩,
    이탈리아,
    일본,
    멕시코,
    싱가포르,
    스페인,
    대만,
    태국,
    미국
}

