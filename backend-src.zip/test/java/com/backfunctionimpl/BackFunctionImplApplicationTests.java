package com.backfunctionimpl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackFunctionImplApplicationTests {

    @Test
    void contextLoads() {
    }

}
